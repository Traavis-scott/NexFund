import * as tf from '@tensorflow/tfjs';

export async function createAndTrainModel(data: number[][], windowSize: number) {
  // Prepare sequences for training
  const sequences = [];
  const labels = [];
  
  for (let i = 0; i < data.length - windowSize; i++) {
    sequences.push(data.slice(i, i + windowSize));
    labels.push(data[i + windowSize][3] > data[i + windowSize - 1][3] ? 1 : 0); // Compare close prices
  }

  const xs = tf.tensor3d(sequences);
  const ys = tf.tensor1d(labels);

  // Create a simple LSTM model
  const model = tf.sequential();
  model.add(tf.layers.lstm({
    units: 50,
    inputShape: [windowSize, data[0].length],
    returnSequences: false
  }));
  model.add(tf.layers.dense({ units: 1, activation: 'sigmoid' }));

  model.compile({
    optimizer: tf.train.adam(0.001),
    loss: 'binaryCrossentropy',
    metrics: ['accuracy']
  });

  // Train the model
  await model.fit(xs, ys, {
    epochs: 50,
    batchSize: 32,
    shuffle: true,
    validationSplit: 0.1
  });

  return model;
}

export async function predictNextMove(
  model: tf.LayersModel,
  data: number[][],
  windowSize: number
): Promise<number> {
  const sequence = data.slice(-windowSize);
  const prediction = await model.predict(tf.tensor3d([sequence])) as tf.Tensor;
  const probabilityUp = await prediction.data();
  return probabilityUp[0];
}

export function calculateReturns(
  predictions: number[],
  actualPrices: number[],
  threshold: number
): {
  trades: { type: 'buy' | 'sell'; price: number; date: string }[];
  totalProfit: number;
  winRate: number;
  maxDrawdown: number;
} {
  let position: 'none' | 'long' = 'none';
  let trades = [];
  let equity = 1000; // Starting capital
  let maxEquity = equity;
  let maxDrawdown = 0;
  let wins = 0;
  let totalTrades = 0;

  for (let i = 0; i < predictions.length; i++) {
    const prediction = predictions[i];
    const price = actualPrices[i];
    
    if (prediction > 0.5 + threshold && position === 'none') {
      position = 'long';
      trades.push({ type: 'buy', price, date: new Date(Date.now() - (predictions.length - i) * 86400000).toISOString() });
    } else if (prediction < 0.5 - threshold && position === 'long') {
      position = 'none';
      trades.push({ type: 'sell', price, date: new Date(Date.now() - (predictions.length - i) * 86400000).toISOString() });
      
      // Calculate trade result
      const lastBuy = trades[trades.length - 2].price;
      const profit = (price - lastBuy) / lastBuy;
      equity *= (1 + profit);
      maxEquity = Math.max(maxEquity, equity);
      maxDrawdown = Math.max(maxDrawdown, (maxEquity - equity) / maxEquity);
      
      if (profit > 0) wins++;
      totalTrades++;
    }
  }

  return {
    trades,
    totalProfit: equity - 1000, // Profit/loss in dollars
    winRate: totalTrades > 0 ? wins / totalTrades : 0,
    maxDrawdown: maxDrawdown * 100 // Convert to percentage
  };
}