import React, { useState } from 'react';
import * as tf from '@tensorflow/tfjs';
import { History, Brain } from 'lucide-react';
import { Chart } from './components/Chart';
import { StrategyForm } from './components/StrategyForm';
import { Results } from './components/Results';
import { createAndTrainModel, predictNextMove, calculateReturns } from './utils/aiBacktest';
import type { CandleData, StrategyResult } from './types';

// Generate more realistic sample data
const sampleData: CandleData[] = Array.from({ length: 100 }, (_, i) => {
  const basePrice = 100;
  const trend = Math.sin(i / 10) * 10;
  const noise = Math.random() * 5 - 2.5;
  const price = basePrice + trend + noise;
  
  return {
    time: new Date(Date.now() - (100 - i) * 86400000).toISOString().split('T')[0],
    open: price,
    high: price + Math.random() * 2,
    low: price - Math.random() * 2,
    close: price + Math.random() * 4 - 2,
    volume: 1000 + Math.random() * 1000
  };
});

function App() {
  const [results, setResults] = useState<StrategyResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const runBacktest = async ({ windowSize, threshold }: { windowSize: number; threshold: number }) => {
    setIsLoading(true);
    try {
      const priceData = sampleData.map(d => [
        d.open,
        d.high,
        d.low,
        d.close,
        d.volume
      ]);

      const model = await createAndTrainModel(priceData, windowSize);

      const predictions = [];
      for (let i = windowSize; i < priceData.length; i++) {
        const sequence = priceData.slice(i - windowSize, i);
        const pred = await predictNextMove(model, sequence, windowSize);
        predictions.push(pred);
      }

      const closePrices = sampleData.slice(windowSize).map(d => d.close);
      const results = calculateReturns(predictions, closePrices, threshold);

      setResults({
        trades: results.trades.map(trade => ({
          date: new Date(trade.date),
          type: trade.type,
          price: trade.price,
          quantity: 1
        })),
        totalProfit: results.totalProfit,
        winRate: results.winRate,
        maxDrawdown: results.maxDrawdown
      });

      model.dispose();
    } catch (error) {
      console.error('Error during backtesting:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-blue-600" />
            <h1 className="text-xl font-semibold text-gray-900">AI Trading Backtest</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <StrategyForm onSubmit={runBacktest} isLoading={isLoading} />
          </div>
          
          <div className="lg:col-span-3 space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <History className="w-5 h-5 text-blue-600" />
                <h2 className="text-lg font-semibold">Price History & Predictions</h2>
              </div>
              <Chart data={sampleData} />
            </div>
            
            <Results results={results} />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;