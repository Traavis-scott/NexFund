export interface Trade {
  date: Date;
  type: 'buy' | 'sell';
  price: number;
  quantity: number;
}

export interface StrategyResult {
  trades: Trade[];
  totalProfit: number;
  winRate: number;
  maxDrawdown: number;
}

export interface CandleData {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}