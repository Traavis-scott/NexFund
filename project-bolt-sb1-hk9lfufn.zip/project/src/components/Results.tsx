import React from 'react';
import { TrendingUp, TrendingDown, BarChart2, Percent } from 'lucide-react';
import type { StrategyResult } from '../types';

interface ResultsProps {
  results: StrategyResult | null;
}

export function Results({ results }: ResultsProps) {
  if (!results) return null;

  const metrics = [
    {
      label: 'Total Profit',
      value: `$${results.totalProfit.toFixed(2)}`,
      icon: results.totalProfit >= 0 ? TrendingUp : TrendingDown,
      color: results.totalProfit >= 0 ? 'text-green-600' : 'text-red-600',
    },
    {
      label: 'Win Rate',
      value: `${(results.winRate * 100).toFixed(1)}%`,
      icon: Percent,
      color: 'text-blue-600',
    },
    {
      label: 'Max Drawdown',
      value: `${results.maxDrawdown.toFixed(1)}%`,
      icon: BarChart2,
      color: 'text-orange-600',
    },
  ];

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h2 className="text-lg font-semibold mb-4">Backtest Results</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {metrics.map((metric) => (
          <div key={metric.label} className="p-4 rounded-lg bg-gray-50">
            <div className="flex items-center gap-2 mb-2">
              <metric.icon className={`w-5 h-5 ${metric.color}`} />
              <span className="text-sm text-gray-600">{metric.label}</span>
            </div>
            <span className={`text-xl font-semibold ${metric.color}`}>
              {metric.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}