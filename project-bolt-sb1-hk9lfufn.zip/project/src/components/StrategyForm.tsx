import React from 'react';
import { Settings } from 'lucide-react';

interface StrategyFormProps {
  onSubmit: (values: { windowSize: number; threshold: number }) => void;
  isLoading: boolean;
}

export function StrategyForm({ onSubmit, isLoading }: StrategyFormProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const windowSize = parseInt(form.windowSize.value);
    const threshold = parseFloat(form.threshold.value);
    onSubmit({ windowSize, threshold });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <Settings className="w-5 h-5 text-blue-600" />
        <h2 className="text-lg font-semibold">AI Strategy Parameters</h2>
      </div>
      
      <div>
        <label htmlFor="windowSize" className="block text-sm font-medium text-gray-700">
          Analysis Window Size
        </label>
        <input
          type="number"
          id="windowSize"
          name="windowSize"
          defaultValue={10}
          min={5}
          max={30}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
        <p className="mt-1 text-sm text-gray-500">Number of days to analyze for patterns</p>
      </div>

      <div>
        <label htmlFor="threshold" className="block text-sm font-medium text-gray-700">
          Prediction Threshold
        </label>
        <input
          type="number"
          id="threshold"
          name="threshold"
          defaultValue={0.1}
          step={0.01}
          min={0.01}
          max={0.5}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
        <p className="mt-1 text-sm text-gray-500">Minimum confidence level for trading signals</p>
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className={`w-full py-2 px-4 rounded-md transition-colors ${
          isLoading
            ? 'bg-gray-400 cursor-not-allowed'
            : 'bg-blue-600 text-white hover:bg-blue-700'
        }`}
      >
        {isLoading ? 'Training AI Model...' : 'Run AI Backtest'}
      </button>
    </form>
  );
}